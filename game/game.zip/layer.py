
count = 4
(bg, obstacle, player, ui) = range(count)
